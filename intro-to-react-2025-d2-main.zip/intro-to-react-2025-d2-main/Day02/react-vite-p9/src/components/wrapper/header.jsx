import logo from "./../../assets/chart.gif";
import { NavLink } from "react-router-dom";
//
function Header(){
  return (
    <header>
      <img src={logo} id="logo" />
			<h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>
        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>
        </ul>
      </nav>
    </header>
  )
};
//
export default Header;
