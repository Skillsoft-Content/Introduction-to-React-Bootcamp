import "./styles.css";
import Home from "./components/home/home";
import Employees from "./components/employees/employees";
//
import { BrowserRouter, Route, Routes } from "react-router-dom";
//
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/employees' element={<Employees />} />
        </Routes>
      </BrowserRouter>
    </>
  )
};
//
export default App;
