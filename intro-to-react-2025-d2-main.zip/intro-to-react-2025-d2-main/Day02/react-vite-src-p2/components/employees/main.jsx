function Main(){
  return (
    <main>
      <h2>Employee List</h2>
    </main>
  )
};
//
export default Main;
