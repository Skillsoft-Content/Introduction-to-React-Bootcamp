import { Component } from "react";
//
class Main extends Component{
  constructor(props){
    super(props);
    this.state = {
      allEmployees : []
    }
  };
  //
  componentDidMount(){
    fetch("http://localhost:3030/employees")
    .then(data => {
      return(data.json());
    })
    .then(response => {
      this.setState({
        allEmployees : response
      });
    })
  };
  //
  render(){
    return (
      <main>
        <h2>Employee List</h2>
      </main>
    )
  };
};
//
export default Main;
